# Airline-Reservation-Program
This is an Airline reservation program coded in C++language . File System is used to store data which is required in this program.

So the file with extension .exe is the program file . This is supported only in Windows. 
This is a Airline reservation system  program which basically works on simple principle that is calculating the fair between two cities.
Fair is calculated on basis of distance between source city and destination city and then tax and concession of fair is also there.
There are two option to enter into this program i.e. as a Administrator or as an user.
Administrator work is to manage the data related to flights. User is the one who needs to book a ticket. The ticket booked will later be stored in file .

Try this program you'll love it.
Password for Administator:"inaeroplane".
